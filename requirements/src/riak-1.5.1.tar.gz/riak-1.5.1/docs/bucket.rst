.. ref-bucket:

==========
RiakBucket
==========

.. currentmodule:: riak.bucket

.. autoclass:: riak.bucket.RiakBucket
