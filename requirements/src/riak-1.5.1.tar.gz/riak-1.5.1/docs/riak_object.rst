.. ref-riak-object:

==========
RiakObject
==========

.. currentmodule:: riak.riak_object

.. autoclass:: riak.riak_object.RiakObject
