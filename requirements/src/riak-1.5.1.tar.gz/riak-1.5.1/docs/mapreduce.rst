.. ref-mapreduce:

=============
RiakMapReduce
=============

.. currentmodule:: riak.mapreduce

.. autoclass:: riak.mapreduce.RiakMapReduce

.. autoclass:: riak.mapreduce.RiakMapReducePhase

.. autoclass:: riak.mapreduce.RiakLinkPhase

.. autoclass:: riak.mapreduce.RiakLink
