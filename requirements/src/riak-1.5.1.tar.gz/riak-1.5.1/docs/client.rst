.. ref-client:

==========
RiakClient
==========

.. currentmodule:: riak.client

.. autoclass:: riak.client.RiakClient
